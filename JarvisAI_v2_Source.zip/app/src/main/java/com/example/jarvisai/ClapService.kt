package com.example.jarvisai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import kotlin.concurrent.thread
import kotlin.math.abs

class ClapService : Service() {
    @Volatile private var running = false
    private var recorder: AudioRecord? = null
    private var lastClap = 0L

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
            NotificationChannel("jarvis_listen", "Jarvis listening", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "jarvis_listen").setContentTitle("Jarvis clap activation")
                .setContentText("Microphone is active for clap detection. Tap to open Jarvis.")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(open).build()
        else Notification.Builder(this).setContentTitle("Jarvis clap activation")
            .setContentText("Microphone is active for clap detection.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        startForeground(7, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!running) startDetection()
        return START_STICKY
    }

    private fun startDetection() {
        running = true
        thread(name = "JarvisClapDetector") {
            val sampleRate = 16000
            val minBuffer = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuffer <= 0) { stopSelf(); return@thread }
            val audio = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, minBuffer * 2)
            recorder = audio
            try {
                audio.startRecording()
                val buffer = ShortArray(1024)
                while (running) {
                    val count = audio.read(buffer, 0, buffer.size)
                    if (count > 0) {
                        var peak = 0
                        for (i in 0 until count) peak = maxOf(peak, abs(buffer[i].toInt()))
                        val now = System.currentTimeMillis()
                        if (peak > 18000 && now - lastClap > 1800) {
                            lastClap = now
                            val launch = Intent(this, MainActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                                putExtra("CLAP_WAKE", true)
                            }
                            startActivity(launch)
                        }
                    }
                }
            } catch (_: Exception) { }
            finally { try { audio.stop() } catch (_: Exception) {}; audio.release(); recorder = null }
        }
    }

    override fun onDestroy() {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
