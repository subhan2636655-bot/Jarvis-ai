package com.example.jarvisai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private var speech: SpeechRecognizer? = null
    private var torchOn = false
    private val reqAudio = 10
    private val reqCamera = 11

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        if (intent?.getBooleanExtra("CLAP_WAKE", false) == true) {
            say("I am listening. How can I help?")
            startListening()
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(26, 30, 26, 30); setBackgroundColor(0xFF07111F.toInt())
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"; textSize = 32f; gravity = Gravity.CENTER
            setTextColor(0xFF55D9FF.toInt())
        }
        status = TextView(this).apply {
            text = "Your personal assistant is ready."
            textSize = 16f; gravity = Gravity.CENTER; setTextColor(-1)
            setPadding(0, 26, 0, 26)
        }
        fun btn(label: String, action: () -> Unit) = Button(this).apply {
            text = label; setOnClickListener { action() }
        }
        root.addView(title); root.addView(status)
        root.addView(btn("🎙 TALK TO JARVIS") { startListening() })
        root.addView(btn("👏 ENABLE CLAP ACTIVATION") { enableClap() })
        root.addView(btn("STOP CLAP LISTENING") { stopService(Intent(this, ClapService::class.java)); say("Clap listening stopped.") })
        root.addView(btn("FLASHLIGHT ON / OFF") { toggleTorch() })
        val help = TextView(this).apply {
            text = "Commands: open YouTube • flashlight on/off • volume up/down • call 03xxxxxxxxx"
            textSize = 13f; gravity = Gravity.CENTER; setTextColor(0xFFB7C7D8.toInt())
            setPadding(0, 20, 0, 0)
        }
        root.addView(help); setContentView(root)
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            val selected = tts.setLanguage(Locale.getDefault())
            if (selected == TextToSpeech.LANG_MISSING_DATA || selected == TextToSpeech.LANG_NOT_SUPPORTED)
                tts.language = Locale.US
        }
    }

    private fun say(message: String) {
        status.text = message
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun enableClap() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), reqAudio); return
        }
        try {
            startForegroundService(Intent(this, ClapService::class.java))
            say("Clap activation enabled. Keep the app allowed to run in the background.")
        } catch (_: Exception) { say("Could not start clap activation. Open the app and try again.") }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { say("Speech recognition is not available."); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), reqAudio); return
        }
        speech?.destroy()
        speech = SpeechRecognizer.createSpeechRecognizer(this)
        speech?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Processing..." }
            override fun onError(error: Int) { status.text = "Didn't catch that. Tap Talk and retry." }
            override fun onResults(results: Bundle?) {
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                handleCommand(words.lowercase(Locale.getDefault()))
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        speech?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Jarvis")
        })
    }

    private fun handleCommand(command: String) {
        status.text = "You said: $command"
        when {
            command.contains("flashlight") || command.contains("torch") || command.contains("light") ->
                setTorch(!command.contains("off"))
            command.contains("volume up") || command.contains("increase volume") -> {
                (getSystemService(AUDIO_SERVICE) as AudioManager).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                say("Volume increased.")
            }
            command.contains("volume down") || command.contains("decrease volume") -> {
                (getSystemService(AUDIO_SERVICE) as AudioManager).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                say("Volume decreased.")
            }
            command.startsWith("open ") -> openApp(command.removePrefix("open ").trim())
            command.startsWith("call ") -> {
                val number = command.removePrefix("call ").filter { it.isDigit() || it == '+' }
                if (number.length >= 5) {
                    say("Opening dialer. Confirm the call on screen.")
                    startActivity(Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:$number")))
                } else say("Say call followed by a phone number.")
            }
            command.contains("hello") || command.contains("hi jarvis") -> say("Hello. I am Jarvis. How can I help?")
            command.contains("time") -> say("The time is " + java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date()))
            else -> say("I heard you say $command. This starter does not have an online AI brain yet.")
        }
    }

    private fun openApp(name: String) {
        val apps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        val app = apps.firstOrNull { packageManager.getApplicationLabel(it).toString().lowercase().contains(name) }
        val launch = app?.let { packageManager.getLaunchIntentForPackage(it.packageName) }
        if (launch != null) { say("Opening $name."); startActivity(launch) } else say("I could not find that app.")
    }

    private fun toggleTorch() = setTorch(!torchOn)
    private fun setTorch(on: Boolean) {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), reqCamera); return
        }
        try {
            val manager = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = manager.cameraIdList.firstOrNull { manager.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) { say("Flashlight unavailable."); return }
            manager.setTorchMode(id, on); torchOn = on
            say(if (on) "Flashlight on." else "Flashlight off.")
        } catch (_: Exception) { say("Could not control flashlight.") }
    }

    override fun onRequestPermissionsResult(code: Int, permissions: Array<out String>, grants: IntArray) {
        super.onRequestPermissionsResult(code, permissions, grants)
        if (grants.isNotEmpty() && grants[0] == PackageManager.PERMISSION_GRANTED) {
            if (code == reqAudio) startListening()
            if (code == reqCamera) setTorch(true)
        } else Toast.makeText(this, "Permission is required for this feature.", Toast.LENGTH_SHORT).show()
    }
    override fun onDestroy() { speech?.destroy(); if (::tts.isInitialized) tts.shutdown(); super.onDestroy() }
}
